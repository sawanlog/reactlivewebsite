import React from 'react';
import Nav from './Nav';

const Commingsoon = () => {
  return <>
  <div className="header">
        <div className="container">
          <br />
          <a href="/">
            <img src="img/dslogo.png" alt="DS Canteen" />
          </a>
          <Nav />
        </div>
      </div>
  <div>
     <img src="images/comingsoon.jpg" alt="" />
     </div>
  </>;
};

export default Commingsoon;
